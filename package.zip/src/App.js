import React, {useState} from "react";
import Questions from "./Questions/questions";

function App() {
  return(
    <div className="App">
<Questions/>
    </div>
  )
}

export default App;