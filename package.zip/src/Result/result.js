import React  from "react";

const Result = ({score, handleRetryClick, questions}) => {
return (<div className='score-section'>
        <div className="retry-btn"><button onClick={handleRetryClick}>Take the test again</button></div>
        <p><b>Your result:</b><br/><br/>Test time:  00:53:02, average users 00:10:18. <br/><br/><b>Your IQ is 80</b>. 
        This corresponds to a below average level IQ. In this test you have {score} correct answers from {questions.length}.
        This is not a very good result for your age 8. <br/><br/> Please note that the first four questions of the test were only
        the practice questions and they do not count towards the final result.<br/><br/><b>Permenant result link: <br/><br/></b><a href="https://en.testometrika.com/a/hGefTnPjWbtWZi6vnf4zBg/">https://en.testometrika.com/a/hGefTnPjWbtWZi6vnf4zBg/</a></p>
 </div>

)}

export default Result;